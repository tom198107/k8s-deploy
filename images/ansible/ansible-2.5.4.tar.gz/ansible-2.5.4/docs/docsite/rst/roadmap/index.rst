.. _roadmaps:

Ansible Roadmap
===============

The Ansible team develops a roadmap for each major Ansible release. The latest roadmap shows current work; older roadmaps provide a history of the project. 

.. toctree::
   :maxdepth: 1
   :glob:
   :caption: Ansible Release Roadmaps

   ROADMAP*

